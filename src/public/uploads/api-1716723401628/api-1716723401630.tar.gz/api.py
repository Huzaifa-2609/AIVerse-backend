import pandas as pd
from flask import Flask, request, jsonify ,redirect
import pickle


# Load the model
model = pickle.load(open('model.pkl', 'rb'))

app = Flask(__name__)

@app.route('/', methods=['GET'])  # Add a root route for redirection
def index():
    return redirect('/invocations')

@app.route('/invocations', methods=['POST'])
def invoke():
    data = request.get_json()
    if not data or 'x' not in data:
        return jsonify({'error': 'Missing input data or "x" feature'}), 400

    input_data = pd.DataFrame({'x': [data['x']]})

    prediction = model.predict(input_data)[0]
    return jsonify({'prediction': prediction})



@app.route("/ping")
def ping():
    return 'ping'

if __name__ == '__main__':
    app.run(debug=True,port=8080)
